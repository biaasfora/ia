import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.util.Scanner;
import java.util.Random;

//import au.com.bytecode.opencsv.CSVReader;

public class Rodar {
	/*public static void main(String[] args) throws IOException {
	CSVReader reader = new CSVReader(new FileReader("data.csv"));
	FileWriter writer = new FileWriter("out.csv");

	List<String[]> myEntries = reader.readAll();
	List<Cachorro> cachorros = new ArrayList<Cachorro>();

	for (String[] strings : myEntries) {
		Cachorro c = new Cachorro(strings);
	    cachorros.add(c);
	}
*/ public static void main(String[]args) {
	ArrayList<Cachorro> listaDeCaes = new ArrayList<Cachorro>();
	Scanner ler = new Scanner(System.in);
	String BD1 = ler.nextLine();

	for (int i = 0; i < 74; i++) {
		try {

			FileReader arq = new FileReader(BD1);
			BufferedReader lerArq = new BufferedReader(arq);
			String linha = lerArq.readLine();
			System.out.println(listaDeCaes.get(i));
			
			/*raca = (float) Integer.parseInt(linha.substring(0, 2)) * (1 / 100);
			porte = (float) Integer.parseInt(linha.substring(3, 4)) * (1 / 100);
			energia = (float) Integer.parseInt(linha.substring(5, 6)) * (1 / 100);
			brincalhao = (float) Integer.parseInt(linha.substring(7, 8)) * (1 / 100);
			sociavelComCaes = (float) Integer.parseInt(linha.substring(9, 10)) * (1 / 100);
			sociavelComEstranhos = (float) Integer.parseInt(linha.substring(11, 12)) * (1 / 100);
			protecao = (float) Integer.parseInt(linha.substring(13, 14)) * (1 / 100);
			necessidadeDeExercicio = (float) Integer.parseInt(linha.substring(15, 16)) * (1 / 100);
			apegoAoDono = (float) Integer.parseInt(linha.substring(17, 18)) * (1 / 100);
			facilidadeDeTreinamento = (float) Integer.parseInt(linha.substring(19, 20)) * (1 / 100);
			guarda = (float) Integer.parseInt(linha.substring(21, 22)) * (1 / 100);
			higiene = (float) Integer.parseInt(linha.substring(23, 24)) * (1 / 100);

			Cachorro dog = new Cachorro(raca, porte, energia, brincalhao, sociavelComCaes, sociavelComEstranhos,
					protecao, necessidadeDeExercicio, apegoAoDono, facilidadeDeTreinamento, guarda, higiene);
			listaDeCaes.add(dog);
*/
		} catch (IOException e) {
			System.err.printf("Erro na abertura do arquivo: %s.\n", e.getMessage());
		}
	}
}
}

/*
	Kmeans kmeans = new Kmeans();
	for (int k = 1; k <= 5; k++) {
	    Kmeansresultado resultado = kmeans.calcular(cachorros, k);
	    writer.write("------- Con k=" + k + " aux=" + resultado.getAux()
		    + "-------\n");
	    int i = 0;
	    for (Grupo grupo : resultado.getGrupo()) {
		i++;
		writer.write("-- Grupo " + i + " --\n");
		for (Cachorro cachorro : grupo.getCachorros()) {
		    writer.write(cachorro.toString() + "\n");
		}
		writer.write("\n");
		writer.write(grupo.getCentroide().toString());
		writer.write("\n\n");
	    }
	}
	writer.close();
    }
}
*/